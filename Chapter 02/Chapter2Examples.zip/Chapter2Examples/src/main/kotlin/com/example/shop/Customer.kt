package com.example.shop

class Customer {

}
