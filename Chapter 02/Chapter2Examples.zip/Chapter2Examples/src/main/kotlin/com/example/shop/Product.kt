package com.example.shop

class Product {

}
