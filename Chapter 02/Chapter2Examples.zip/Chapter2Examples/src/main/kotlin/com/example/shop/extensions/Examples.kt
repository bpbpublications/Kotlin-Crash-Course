/** Product-related extension functions for the shop application */
@file:JvmName("ProductExtensions")

package com.example.shop.extensions

// Extension functions go here