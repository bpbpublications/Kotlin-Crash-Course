package com.example.util

class CurrencyFormatter {
    companion object {
        fun format(price: Double): String = TODO("Example only, not implemented")
    }
}