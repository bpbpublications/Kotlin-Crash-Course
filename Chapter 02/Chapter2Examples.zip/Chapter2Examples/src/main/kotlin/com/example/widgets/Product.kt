package com.example.widgets

class Product {

}
