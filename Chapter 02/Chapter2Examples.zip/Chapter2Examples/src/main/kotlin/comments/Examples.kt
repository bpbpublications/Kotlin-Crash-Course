package comments

// This is a single-line comment
val productName = "Laptop"

/*
This is a multi-line comment
that spans several lines
*/
val productPrice = 1200.0

fun calculateTotalPrice(items: List<Item>): Double {/*comment*/ return 0.0 }

class Item {

}
