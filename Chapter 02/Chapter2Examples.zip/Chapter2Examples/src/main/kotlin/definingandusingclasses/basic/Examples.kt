package definingandusingclasses.basic

class Product {
    val name: String = "ProductA"
    val price: Double = 10.0
}

val productA = Product()

