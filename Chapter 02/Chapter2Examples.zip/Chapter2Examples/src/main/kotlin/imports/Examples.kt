package imports

import com.example.shop.Product
import com.example.shop.Customer
import com.example.shop.*
import com.example.widgets.Product as WidgetProduct
