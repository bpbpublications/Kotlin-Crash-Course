package namingandorganisation.functions

const val DEFAULT_SHIPPING_FEE = 10.0

fun calculateTotalPrice(items: List<Item>): Double {
    return 0.0
}

fun addItemToCart(item: Item) {
    /*...*/
}

fun applyDiscount(discount: Double) {
    /*...*/
}

// Top-level functions
fun calculateShippingCost(items: List<Product>): Double {
    return 0.0
}

class ShoppingCart {
    // Constructors and properties

    // Functions related to updating product list in shopping cart
    fun addProduct(product: Product) {
        /*...*/
    }

    fun removeProduct(product: Product) {
        /*...*/
    }

    private fun updateTotal() {
        /*...*/
    }
}

class Item {

}

class Product {

}

