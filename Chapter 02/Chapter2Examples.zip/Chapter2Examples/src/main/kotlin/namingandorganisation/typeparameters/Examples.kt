package namingandorganisation.typeparameters

class ProductStorage<TProduct>(val product: TProduct)