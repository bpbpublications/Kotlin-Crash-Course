package variables.mutable

class RaceCar(
    // ...
    internal var currentSpeed: Double = 0.0,
    // ...
)
