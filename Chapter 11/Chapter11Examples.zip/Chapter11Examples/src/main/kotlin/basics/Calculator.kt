package basics

/**
 * See test in src/test/kotlin folder
 */
class Calculator {
    fun add(a: Int, b: Int): Int = a + b
    fun subtract(a: Int, b: Int): Int = a - b
}


