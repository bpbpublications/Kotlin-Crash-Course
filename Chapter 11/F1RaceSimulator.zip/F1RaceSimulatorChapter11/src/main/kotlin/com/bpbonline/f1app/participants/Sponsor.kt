package com.bpbonline.f1app.participants

data class Sponsor(val name: String, val amount: Double)
