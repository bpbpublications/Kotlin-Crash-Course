package application

fun analyse(value: String)
        : String = "Complex analysis results of $value"
